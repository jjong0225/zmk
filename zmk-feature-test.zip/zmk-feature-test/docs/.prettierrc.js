module.exports = {
  endOfLine: "auto",
};
