module.exports = {
    endOfLine: "auto",
};
